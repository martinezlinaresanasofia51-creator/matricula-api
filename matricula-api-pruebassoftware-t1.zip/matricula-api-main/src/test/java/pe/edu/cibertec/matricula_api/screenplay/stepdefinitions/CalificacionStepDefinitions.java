package pe.edu.cibertec.matricula_api.screenplay.stepdefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Y;
import pe.edu.cibertec.matricula_api.screenplay.questions.ElHistorial;
import pe.edu.cibertec.matricula_api.screenplay.task.BuscarMatricula;
import pe.edu.cibertec.matricula_api.screenplay.task.CalificarMatricula;
import pe.edu.cibertec.matricula_api.screenplay.task.ConsultarHistorial;
import pe.edu.cibertec.matricula_api.screenplay.task.IniciarSesion;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorCalled;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.closeTo;
import static org.hamcrest.Matchers.equalTo;

/**
 * Los actores (Rosa, Marco, Lucia) se crean con CallAnApi en ComunesStepDefinitions.
 * El token y el id de la matrícula viven en la memoria de cada actor.
 * Nota: {double} usa el idioma del feature (es): la coma es el separador decimal.
 */
public class CalificacionStepDefinitions {

    @Y("{word} se identifica como {string} con la clave {string}")
    public void seIdentifica(String actor, String usuario, String clave) {
        theActorCalled(actor).attemptsTo(IniciarSesion.como(usuario, clave));
    }

    @Y("{word} ubica su matrícula del curso {string}")
    public void ubicaSuMatricula(String alumna, String curso) {
        theActorCalled(alumna).attemptsTo(BuscarMatricula.delCurso(curso));
    }

    @Cuando("{word} registra la nota {double} en la matrícula de {word}")
    public void registraLaNota(String docente, double nota, String alumna) {
        // El id no se escribe fijo: lo recuerda la alumna tras consultar GET /api/matriculas
        Long idMatricula = theActorCalled(alumna).recall("idMatricula");
        if (idMatricula == null) {
            throw new AssertionError(alumna + " no encontró la matrícula en GET /api/matriculas");
        }
        theActorCalled(docente).attemptsTo(CalificarMatricula.conNota(nota).enLaMatricula(idMatricula));
    }

    @Cuando("{word} consulta su historial académico")
    public void consultaSuHistorial(String alumna) {
        theActorCalled(alumna).attemptsTo(ConsultarHistorial.de("i202610005"));
    }

    @Y("el curso {string} figura como {string} en el historial")
    public void laCondicionEs(String curso, String condicion) {
        theActorInTheSpotlight().should(seeThat(ElHistorial.condicionDe(curso), equalTo(condicion)));
    }

    @Y("los créditos aprobados son {int}")
    public void losCreditosAprobados(int creditos) {
        theActorInTheSpotlight().should(seeThat(ElHistorial.creditosAprobados(), equalTo(creditos)));
    }

    @Y("el promedio ponderado es {double}")
    public void elPromedioPonderado(double promedio) {
        theActorInTheSpotlight().should(seeThat(ElHistorial.promedioPonderado(), closeTo(promedio, 0.001)));
    }
}
