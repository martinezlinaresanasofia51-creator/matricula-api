package pe.edu.cibertec.matricula_api.screenplay.stepdefinitions;

import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Hooks {

    // TODO: reemplaza con tus datos reales
    private static final String NOMBRE = "TU NOMBRE COMPLETO";
    private static final String CODIGO = "i202414395";

    /** Se ejecuta una sola vez, antes de todas las pruebas: deja tu identificación en la consola. */
    @BeforeAll
    public static void identificarAlumno() {
        String fechaHora = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        System.out.println("==================================================");
        System.out.println(" Alumno : " + NOMBRE);
        System.out.println(" Código : " + CODIGO);
        System.out.println(" Fecha  : " + fechaHora);
        System.out.println("==================================================");
    }

    @Before
    public void beforeScenario() {
        OnStage.setTheStage(new OnlineCast());
    }
}
