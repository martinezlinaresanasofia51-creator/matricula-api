package pe.edu.cibertec.matricula_api.screenplay.task;

import io.restassured.http.ContentType;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Patch;

import java.util.Map;

public class CalificarMatricula implements Task {

    private final double nota;
    private final long idMatricula;

    private CalificarMatricula(double nota, long idMatricula) {
        this.nota = nota;
        this.idMatricula = idMatricula;
    }

    public static Builder conNota(double nota) {
        return new Builder(nota);
    }

    public static class Builder {
        private final double nota;

        private Builder(double nota) {
            this.nota = nota;
        }

        public CalificarMatricula enLaMatricula(long id) {
            return new CalificarMatricula(nota, id);
        }
    }

    @Override
    @Step("{0} registra la nota #nota en la matrícula #idMatricula")
    public <T extends Actor> void performAs(T actor) {
        String accessToken = actor.recall("accessToken");
        actor.attemptsTo(
                Patch.to("/api/matriculas/{id}/nota")
                        .with(req -> req.auth().oauth2(accessToken)
                                .contentType(ContentType.JSON)
                                .pathParam("id", idMatricula)
                                .body(Map.of("nota", nota)))
        );
    }
}
