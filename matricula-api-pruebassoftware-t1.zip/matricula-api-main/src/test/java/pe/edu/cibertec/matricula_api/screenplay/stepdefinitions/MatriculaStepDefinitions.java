package pe.edu.cibertec.matricula_api.screenplay.stepdefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Dado;
import io.cucumber.java.es.Entonces;
import io.cucumber.java.es.Y;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import net.serenitybdd.model.environment.EnvironmentSpecificConfiguration;
import net.serenitybdd.rest.SerenityRest;
import net.thucydides.model.environment.SystemEnvironmentVariables;

import java.util.List;
import java.util.Map;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

/**
 * Cucumber crea una instancia nueva de esta clase por escenario, por eso los campos
 * (token, id de la matrícula, total cotizado) no se mezclan entre escenarios.
 * Todos los datos de prueba (alumno, curso, método, montos, códigos) vienen del .feature.
 */
public class MatriculaStepDefinitions {

    private final String baseUrl = EnvironmentSpecificConfiguration
            .from(SystemEnvironmentVariables.currentEnvironmentVariables())
            .getProperty("restapi.baseurl");

    private String alumno;
    private String token;
    private Long idMatricula;
    private double totalCotizado;
    private Response respuesta;

    // ---------- Antecedentes ----------

    @Dado("que el alumno {string} inicia sesión con la clave {string}")
    public void iniciaSesion(String username, String clave) {
        alumno = username;
        Response login = base()
                .body(Map.of("username", username, "password", clave))
                .post("/api/auth/login");
        assertThat("el login debe responder 200", login.statusCode(), equalTo(200));
        token = login.jsonPath().getString("accessToken");
    }

    // ---------- Escenario 1 y 2 ----------

    @Cuando("cotiza el curso {string}")
    public void cotizaElCurso(String curso) {
        respuesta = autenticado()
                .body(Map.of("codigoAlumno", alumno, "cursos", List.of(curso)))
                .post("/api/matriculas/cotizacion");
        if (respuesta.statusCode() == 200) {
            totalCotizado = respuesta.jsonPath().getDouble("total");
        }
    }

    @Y("la cotización tiene {int} créditos, subtotal {double}, descuento {int} y total {double}")
    public void laCotizacionTiene(int creditos, double subtotal, int descuento, double total) {
        assertThat(respuesta.jsonPath().getInt("creditos"), equalTo(creditos));
        assertThat(respuesta.jsonPath().getDouble("subtotal"), equalTo(subtotal));
        assertThat(respuesta.jsonPath().getInt("descuento"), equalTo(descuento));
        assertThat(respuesta.jsonPath().getDouble("total"), equalTo(total));
    }

    @Y("se matricula en el curso {string}")
    public void seMatriculaEnElCurso(String curso) {
        respuesta = autenticado()
                .body(Map.of("codigoAlumno", alumno, "codigoCurso", curso))
                .post("/api/matriculas");
        if (respuesta.statusCode() == 201) {
            idMatricula = respuesta.jsonPath().getLong("id");   // el id sale de la respuesta, no se escribe fijo
        }
    }

    @Y("el estado de la matrícula es {string}")
    public void elEstadoDeLaMatriculaEs(String estado) {
        assertThat(respuesta.jsonPath().getString("estado"), equalTo(estado));
    }

    @Y("el monto de la matrícula es igual al total de la cotización")
    public void elMontoEsIgualALaCotizacion() {
        assertThat(respuesta.jsonPath().getDouble("monto"), equalTo(totalCotizado));
    }

    @Y("la respuesta cumple el contrato JSON {string}")
    public void cumpleElContrato(String esquema) {
        respuesta.then().body(matchesJsonSchemaInClasspath("schemas/" + esquema));
    }

    @Cuando("paga la matrícula con el método {string}")
    public void pagaLaMatricula(String metodo) {
        respuesta = autenticado()
                .body(Map.of("metodo", metodo))
                .patch("/api/matriculas/{id}/pagar", idMatricula);
    }

    @Y("la matrícula tiene fecha de pago")
    public void tieneFechaDePago() {
        assertThat(respuesta.jsonPath().getString("fechaPago"), not(emptyOrNullString()));
    }

    @Y("en los pagos existe el pago de la matrícula con método {string} y número de operación con formato {string}")
    public void existeElPago(String metodo, String formato) {
        Response pagos = autenticado().get("/api/pagos");
        assertThat(pagos.statusCode(), equalTo(200));

        // "OP-000000" -> regex OP-\d{6}: cada 0 del formato representa un dígito
        String regex = formato.replace("0", "\\d");
        String ruta = "find { it.idMatricula == " + idMatricula + " }";

        assertThat("no existe un pago para la matrícula " + idMatricula,
                pagos.jsonPath().getMap(ruta), notNullValue());
        assertThat(pagos.jsonPath().getString(ruta + ".metodo"), equalTo(metodo));
        assertThat(pagos.jsonPath().getString(ruta + ".numeroOperacion"), matchesPattern(regex));
    }

    @Entonces("el código HTTP es {int}")
    public void elCodigoHttpEs(int status) {
        assertThat(respuesta.statusCode(), equalTo(status));
    }

    // ---------- Escenario 3 ----------

    @Dado("que el alumno tiene pagada su matrícula del curso {string}")
    public void tienePagadaLaMatricula(String curso) {
        // Se apoya en lo que dejó el Escenario 2, pero sin variables compartidas ni ids fijos:
        // consulta GET /api/matriculas (el alumno solo ve las suyas) y toma el id de la respuesta.
        Response lista = autenticado()
                .queryParam("curso", curso)
                .queryParam("estado", "PAGADA")
                .get("/api/matriculas");
        assertThat(lista.statusCode(), equalTo(200));
        assertThat("no hay matrícula pagada de " + curso + ": ejecuta antes el Escenario 2",
                lista.jsonPath().getList("$"), not(empty()));
        idMatricula = lista.jsonPath().getLong("[0].id");
    }

    @Cuando("intenta anular esa matrícula")
    public void intentaAnular() {
        respuesta = autenticado().patch("/api/matriculas/{id}/anular", idMatricula);
    }

    @Y("el campo codigo del error es {string}")
    public void elCodigoDelErrorEs(String codigo) {
        assertThat(respuesta.jsonPath().getString("codigo"), equalTo(codigo));
    }

    // ---------- Utilitarios ----------

    private RequestSpecification base() {
        return SerenityRest.given().baseUri(baseUrl).contentType(ContentType.JSON);
    }

    private RequestSpecification autenticado() {
        return base().auth().oauth2(token);
    }
}
