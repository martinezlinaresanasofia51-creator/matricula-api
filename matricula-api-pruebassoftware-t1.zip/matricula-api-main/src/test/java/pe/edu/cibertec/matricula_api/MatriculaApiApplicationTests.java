package pe.edu.cibertec.matricula_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MatriculaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
