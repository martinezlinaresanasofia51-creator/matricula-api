package pe.edu.cibertec.matricula_api.screenplay.task;

import io.restassured.response.Response;
import net.serenitybdd.annotations.Step;
import net.serenitybdd.rest.SerenityRest;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

public class BuscarMatricula implements Task {

    private final String curso;

    public BuscarMatricula(String curso) {
        this.curso = curso;
    }

    public static BuscarMatricula delCurso(String curso) {
        return new BuscarMatricula(curso);
    }

    @Override
    @Step("{0} consulta sus matrículas y ubica la del curso #curso")
    public <T extends Actor> void performAs(T actor) {
        String accessToken = actor.recall("accessToken");
        actor.attemptsTo(
                Get.resource("/api/matriculas")
                        .with(req -> req.auth().oauth2(accessToken).queryParam("curso", curso))
        );
        Response respuesta = SerenityRest.lastResponse();
        if (respuesta.statusCode() == 200 && !respuesta.jsonPath().getList("$").isEmpty()) {
            // El id sale de la respuesta y queda en la memoria del actor
            actor.remember("idMatricula", respuesta.jsonPath().getLong("[0].id"));
        }
    }
}
