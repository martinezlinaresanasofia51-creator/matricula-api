package pe.edu.cibertec.matricula_api.screenplay.task;

import net.serenitybdd.annotations.Step;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.rest.interactions.Get;

public class ConsultarPerfil implements Task {

    public static ConsultarPerfil conSuToken() {
        return new ConsultarPerfil();
    }

    @Override
    @Step("{0} consulta su perfil con el accessToken que recuerda")
    public <T extends Actor> void performAs(T actor) {
        String accessToken = actor.recall("accessToken");
        actor.attemptsTo(
                Get.resource("/api/auth/perfil")
                        .with(req -> req.auth().oauth2(accessToken))
        );
    }
}
