package pe.edu.cibertec.matricula_api.screenplay.stepdefinitions;

import io.cucumber.java.es.Cuando;
import io.cucumber.java.es.Y;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import pe.edu.cibertec.matricula_api.screenplay.questions.ElCodigoDeError;
import pe.edu.cibertec.matricula_api.screenplay.task.*;

import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static net.serenitybdd.screenplay.actors.OnStage.theActorInTheSpotlight;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.not;

/**
 * El actor se crea con CallAnApi en ComunesStepDefinitions ("que {word} consulta la API de matricula").
 * Los tokens se guardan con actor.remember(...) y se leen con actor.recall(...).
 */
public class SeguridadStepDefinitions {

    @Cuando("inicia sesión con el usuario {string} y la clave {string}")
    public void iniciaSesion(String usuario, String clave) {
        theActorInTheSpotlight().attemptsTo(IniciarSesion.como(usuario, clave));
    }

    @Cuando("intenta iniciar sesión con el usuario {string} y la clave {string}")
    public void intentaIniciarSesion(String usuario, String clave) {
        theActorInTheSpotlight().attemptsTo(IniciarSesion.como(usuario, clave));
    }

    @Y("renueva su sesión con el refresh token")
    public void renuevaSuSesion() {
        Actor actor = theActorInTheSpotlight();
        // Se guardan los tokens originales antes de que el refresh los reemplace en la memoria
        actor.remember("accessTokenOriginal", actor.<String>recall("accessToken"));
        actor.remember("refreshTokenOriginal", actor.<String>recall("refreshToken"));
        actor.attemptsTo(RenovarToken.usando("refreshToken"));
    }

    @Y("los tokens recibidos son distintos a los anteriores")
    public void losTokensSonNuevos() {
        Actor actor = theActorInTheSpotlight();
        actor.should(
                seeThat(recordado("accessToken"), not(equalTo(actor.<String>recall("accessTokenOriginal")))),
                seeThat(recordado("refreshToken"), not(equalTo(actor.<String>recall("refreshTokenOriginal"))))
        );
    }

    @Cuando("intenta renovar otra vez con el refresh token original")
    public void renuevaConElOriginal() {
        theActorInTheSpotlight().attemptsTo(RenovarToken.usando("refreshTokenOriginal"));
    }

    @Cuando("consulta su perfil con su accessToken")
    public void consultaSuPerfil() {
        theActorInTheSpotlight().attemptsTo(ConsultarPerfil.conSuToken());
    }

    @Y("cierra sesión")
    public void cierraSesion() {
        theActorInTheSpotlight().attemptsTo(CerrarSesion.actual());
    }

    @Y("intenta listar todos los alumnos")
    public void intentaListarAlumnos() {
        theActorInTheSpotlight().attemptsTo(ListarAlumnos.todos());
    }

    @Y("el error tiene código {string}")
    public void elErrorTieneCodigo(String codigo) {
        theActorInTheSpotlight().should(seeThat(ElCodigoDeError.enLaRespuesta(), equalTo(codigo)));
    }

    private static Question<String> recordado(String clave) {
        return Question.about("el " + clave + " que recuerda el actor")
                .answeredBy(actor -> actor.recall(clave));
    }
}
