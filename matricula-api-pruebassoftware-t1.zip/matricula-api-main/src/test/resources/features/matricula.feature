# language: es
@P1
Característica: Matrícula del alumno
  Como alumna de CIBERTEC
  Quiero cotizar, matricularme y pagar un curso
  Para asegurar mi vacante del ciclo

  Antecedentes:
    Dado que el alumno "i202610003" inicia sesión con la clave "Cibertec2026"

  Escenario: Cotizar el curso
    Cuando cotiza el curso "PI5620"
    Entonces el código HTTP es 200
    Y la cotización tiene 6 créditos, subtotal 720,0, descuento 0 y total 720,0

  Escenario: Matricularse y pagar el curso
    Cuando cotiza el curso "PI5620"
    Y se matricula en el curso "PI5620"
    Entonces el código HTTP es 201
    Y el estado de la matrícula es "REGISTRADA"
    Y el monto de la matrícula es igual al total de la cotización
    Y la respuesta cumple el contrato JSON "matricula.json"
    Cuando paga la matrícula con el método "TARJETA"
    Entonces el código HTTP es 200
    Y el estado de la matrícula es "PAGADA"
    Y la matrícula tiene fecha de pago
    Y en los pagos existe el pago de la matrícula con método "TARJETA" y número de operación con formato "OP-000000"

  Escenario: Regla de negocio que debe fallar - anular la matrícula pagada
    Dado que el alumno tiene pagada su matrícula del curso "PI5620"
    Cuando intenta anular esa matrícula
    Entonces el código HTTP es 409
    Y el campo codigo del error es "MATRICULA_PAGADA"
    Y la respuesta cumple el contrato JSON "error.json"
