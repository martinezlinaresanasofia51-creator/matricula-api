# language: es
@P2
Característica: Seguridad de la sesión

  Escenario: Rotación del refresh token
    Dado que Carla consulta la API de matricula
    Cuando inicia sesión con el usuario "i202610003" y la clave "Cibertec2026"
    Y renueva su sesión con el refresh token
    Entonces el codigo de respuesta es 200
    Y los tokens recibidos son distintos a los anteriores
    Y la respuesta cumple el esquema "token.json"
    Cuando intenta renovar otra vez con el refresh token original
    Entonces el codigo de respuesta es 401
    Y el error tiene código "REFRESH_REUTILIZADO"
    Y la respuesta cumple el esquema "error.json"
    Cuando consulta su perfil con su accessToken
    Entonces el codigo de respuesta es 401
    Y el error tiene código "TOKEN_INVALIDO"
    Y la respuesta cumple el esquema "error.json"

  Escenario: Cierre de sesión
    Dado que Carla consulta la API de matricula
    Cuando inicia sesión con el usuario "i202610003" y la clave "Cibertec2026"
    Y cierra sesión
    Entonces el codigo de respuesta es 204
    Cuando consulta su perfil con su accessToken
    Entonces el codigo de respuesta es 401
    Y el error tiene código "TOKEN_INVALIDO"
    Y la respuesta cumple el esquema "error.json"

  # Las filas dependen del orden: cada una es un intento sobre la misma cuenta.
  # Para repetir este escenario reinicia la API (el bloqueo dura 15 minutos).
  Esquema del escenario: Bloqueo de cuenta por intentos fallidos
    Dado que Jorge consulta la API de matricula
    Cuando intenta iniciar sesión con el usuario "i202610004" y la clave "<clave>"
    Entonces el codigo de respuesta es <estado>
    Y el error tiene código "<codigo>"
    Y la respuesta cumple el esquema "error.json"

    Ejemplos:
      | intento             | clave        | estado | codigo                 |
      | 1 (incorrecta)      | ClaveMala1   | 401    | CREDENCIALES_INVALIDAS |
      | 2 (incorrecta)      | ClaveMala2   | 401    | CREDENCIALES_INVALIDAS |
      | 3 (incorrecta)      | ClaveMala3   | 401    | CREDENCIALES_INVALIDAS |
      | 4 (incorrecta)      | ClaveMala4   | 401    | CREDENCIALES_INVALIDAS |
      | 5 (incorrecta)      | ClaveMala5   | 423    | CUENTA_BLOQUEADA       |
      | 6 (clave correcta)  | Cibertec2026 | 423    | CUENTA_BLOQUEADA       |

  Escenario: Alumno sin permiso de administrador
    Dado que Carla consulta la API de matricula
    Cuando inicia sesión con el usuario "i202610003" y la clave "Cibertec2026"
    Y intenta listar todos los alumnos
    Entonces el codigo de respuesta es 403
    Y el error tiene código "ACCESO_DENEGADO"
    Y la respuesta cumple el esquema "error.json"
