# language: es
@P3
Característica: Calificación de matrículas

  Esquema del escenario: El docente registra la nota y el historial se actualiza
    Dado que Rosa consulta la API de matricula
    Y que Marco consulta la API de matricula
    Y Rosa se identifica como "i202610005" con la clave "Cibertec2026"
    Y Marco se identifica como "D0001" con la clave "Cibertec2026"
    Y Rosa ubica su matrícula del curso "PI5620"
    Cuando Marco registra la nota <nota> en la matrícula de Rosa
    Entonces el codigo de respuesta es 200
    Cuando Rosa consulta su historial académico
    Entonces el codigo de respuesta es 200
    Y la respuesta cumple el esquema "historial.json"
    Y el curso "PI5620" figura como "<condicion>" en el historial
    Y los créditos aprobados son <creditos>
    Y el promedio ponderado es <promedio>

    Ejemplos:
      | nota | condicion   | creditos | promedio |
      | 15   | APROBADO    | 13       | 15,23    |
      | 12,5 | DESAPROBADO | 7        | 14,08    |

  Escenario: Un docente que no dicta el curso intenta registrar la nota
    Dado que Rosa consulta la API de matricula
    Y que Lucia consulta la API de matricula
    Y Rosa se identifica como "i202610005" con la clave "Cibertec2026"
    Y Lucia se identifica como "D0002" con la clave "Cibertec2026"
    Y Rosa ubica su matrícula del curso "PI5620"
    Cuando Lucia registra la nota 15 en la matrícula de Rosa
    Entonces el codigo de respuesta es 403
    Y el error tiene código "ACCESO_DENEGADO"
    Y la respuesta cumple el esquema "error.json"

  Escenario: No se puede calificar una matrícula que no está pagada
    Dado que Rosa consulta la API de matricula
    Y que Marco consulta la API de matricula
    Y Rosa se identifica como "i202610005" con la clave "Cibertec2026"
    Y Marco se identifica como "D0001" con la clave "Cibertec2026"
    Y Rosa ubica su matrícula del curso "PS5511"
    Cuando Marco registra la nota 15 en la matrícula de Rosa
    Entonces el codigo de respuesta es 409
    Y el error tiene código "MATRICULA_NO_PAGADA"
    Y la respuesta cumple el esquema "error.json"
