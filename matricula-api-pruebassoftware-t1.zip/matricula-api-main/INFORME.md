# Informe - Evaluación Continua T1 (Pruebas de Software)

**Alumno:** TU NOMBRE COMPLETO  
**Código:** i202414395 (D = 5)  
**Fila de datos:** alumno i202610003 (Carla Quispe) | curso PI5620 | método TARJETA | falla: anular la matrícula pagada

## Pregunta 1

### Cálculo de la cotización (a mano)
| Concepto | Cálculo | Valor |
|---|---|---|
| Créditos PI5620 | dato del curso | 6 |
| Subtotal | 6 × S/ 120 | S/ 720,0 |
| Descuento | promedio 12,0 (< 15) | 0 % |
| Total | 720 − 0 | S/ 720,0 |

### Escenario 3: regla que falla
- Respuesta: HTTP **409**, codigo **MATRICULA_PAGADA**.
- Regla: una matrícula pagada no se puede anular.
- Por qué no lo detiene otra validación antes: en `MatriculaService.anular()` el orden es (1) existe la matrícula, (2) pertenece al alumno, (3) ya está ANULADA, (4) está PAGADA. La matrícula existe, es de Carla y no está anulada, por eso llega a la cuarta.

### Capturas
(Pega aquí: consola con nombre/código/fecha, ejecución de los 3 escenarios y reporte Serenity.)

## Pregunta 2

Fila: alumno i202610003 (Escenarios 1, 2 y 4). El Escenario 3 usa siempre i202610004.

| Escenario | Resultado esperado |
|---|---|
| 1. Primer refresh | 200, tokens nuevos |
| 1. Refresh original otra vez | 401 REFRESH_REUTILIZADO |
| 1. accessToken nuevo después | 401 TOKEN_INVALIDO |
| 2. Logout | 204 |
| 2. Perfil con el mismo token | 401 TOKEN_INVALIDO |
| 3. Intentos 1 a 4 con clave mala | 401 CREDENCIALES_INVALIDAS |
| 3. Intento 5 con clave mala | 423 CUENTA_BLOQUEADA |
| 3. Clave correcta | 423 CUENTA_BLOQUEADA |
| 4. GET /api/alumnos como alumno | 403 ACCESO_DENEGADO |

**Por qué el accessToken nuevo también es rechazado (Esc. 1):** el refresh ya usado está revocado; al reutilizarlo la API lo trata como robo y revoca todas las sesiones del usuario. El accessToken lleva el id de su sesión (`sid`) y en cada petición se verifica que la sesión siga activa, así que queda invalidado aunque no haya vencido.

**Por qué la clave correcta no entra (Esc. 3):** en `login`, la comprobación de cuenta bloqueada va antes de comparar la contraseña, así que mientras dure el bloqueo (15 min) se responde 423 sin evaluar la clave.

### Capturas
(Pega aquí la ejecución de los 4 escenarios.)

## Pregunta 3

Docente D0001 (Marco Salazar) califica PI5620 (6 créditos) de Rosa Medina (i202610005). Mi D = 5, por lo tanto las notas son 10 + 5 = **15** y **12,5**.

Historial de Rosa antes de calificar (2026-1): LP5401 (4 créditos, nota 15) y AS5402 (3 créditos, nota 16). Se aprueba con 13.

| Concepto | Fila nota = 15 | Fila nota = 12,5 |
|---|---|---|
| Suma ponderada | 4×15 + 3×16 + 6×15 = 60 + 48 + 90 = 198 | 60 + 48 + 6×12,5 = 60 + 48 + 75 = 183 |
| Créditos con nota | 4 + 3 + 6 = 13 | 13 |
| Promedio ponderado | 198 / 13 = 15,2307… ≈ **15,23** | 183 / 13 = 14,0769… ≈ **14,08** |
| Condición de PI5620 | 15 ≥ 13 → **APROBADO** | 12,5 < 13 → **DESAPROBADO** |
| Créditos aprobados | 4 + 3 + 6 = **13** | 4 + 3 = **7** (PI5620 no suma) |

Docente que no dicta el curso (D0002): 403 ACCESO_DENEGADO. Matrícula no pagada (PS5511): 409 MATRICULA_NO_PAGADA.

### La fila 12.5 escrita con punto
(Describe aquí lo que viste en tu captura.) Causa a confirmar con tu ejecución: el feature está en español (`# language: es`) y Cucumber interpreta `{double}` con la configuración regional del idioma del feature. En español la coma es el separador decimal y el punto es separador de miles, así que `12.5` no se lee como 12,5 sino como 125. La nota 125 sale del rango 0–20 de `NotaRequest` y la API la rechaza (400 DATOS_INVALIDOS), por lo que el escenario falla.

### Capturas
(Pega aquí la consola y el reporte `target/site/serenity/index.html`.)
